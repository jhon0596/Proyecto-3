/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eTec.clases.java;

/**
 *
 * @author Jonathan
 */

import eTec.clases.entity.Administrador;
import static eTec.clases.java.BinarySearch.binarySearchCodigo;
import static eTec.clases.java.BinarySearch.binarySearchNombre;
import static eTec.clases.java.bubblesort.bubbleSort;
import static eTec.clases.java.bubblesort.bubbleSortCodigo;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
@Named("login")
@RequestScoped 
public class Login {
    private ObjetoaXML XMLManager = new ObjetoaXML();
    private String nombre;
    private String codigo;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
   public String Acceso(String nombre, String codigo){
      LinkList lista = XMLManager.CrearObjeto();
      LinkList listaNombre = bubbleSort(lista);
      LinkList listaCodigo = bubbleSortCodigo(lista);
       if(binarySearchNombre(listaNombre,nombre)==true&& binarySearchCodigo(listaCodigo,codigo)==true){
           return "index.xhtml"; 
       }     
       else{
           return "datosIncorrectos.xhtml";
           
       }
        
   }
}

