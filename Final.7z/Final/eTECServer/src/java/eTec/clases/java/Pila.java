package eTec.clases.java;

import eTec.clases.entity.Administrador;
import eTec.clases.entity.Tienda;

/**
 * Created by Gabriel on 5/6/2017.
 */
public class Pila {
    private Link tope;
    private Link fondo;
    public Pila(){
        this.tope = null;
        this.fondo = null;
    }
    public boolean isEmpty(){
        return tope == null;
    }
    public void push(Administrador T){//inseta un nuevo valor
        Link link = new Link(T);
        push(link);
    }
    private void push(Link link){
        if(tope==null){
            this.tope = link;
            this.fondo = link;
        }
        else{
            link.setNext(tope);
            this.tope = link;
        }
    }
    public void remover(){
        this.tope = tope.getNext();
    }

    public Link pop(){//saca un nuevo valor de la pila  y lo remueve de la pila
        if(tope ==null){
            System.out.println("Pila esta vacia");
            return null;
        }
        else{
            Link LinkImprimir = tope;
            remover();
            return LinkImprimir;
        }
    }
    public void peek(){
        tope.displayCola();
    }
    public void display(){
        Link Link = tope;
        while (Link != null){
            Link.displayCola();
            Link = Link.getNext();
        }
    }

    public Link getTope() {
        return tope;
    }

    public static void main(String[] args) {
        Pila pila = new Pila();
        pila.pop();
        pila.pop();
        pila.pop();
        pila.pop();
    }
}

