/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eTec.clases.java;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import eTec.clases.entity.*;
import java.util.Arrays;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jonathan
 */
@Named("grafo")
@RequestScoped
@XmlRootElement
public  class Grafo {
    private ObjetoaXML XMLManager = new ObjetoaXML();
    private static Grafo instance;
    @XmlElement
    private int cantFilas;
    @XmlElement
    private int cantColumnas;
    @XmlElement
    private int cantInsertados;
    private int INF = 99999999;
    @XmlElement
    int[][] matriz;
    @XmlElementWrapper 
    @XmlElement     
    NodoGrafo[] arrayReferencia = new NodoGrafo[10];
    protected Grafo(int cantNodos){
        matriz = new int[cantNodos][cantNodos];//matriz que representa al grafo
        arrayReferencia = new NodoGrafo[cantNodos];
        Tienda tiendameter = new Tienda();
        tiendameter.setIdGrafo(0);
        NodoGrafo nodo = new NodoGrafo((Tienda)tiendameter);
        Arrays.fill(arrayReferencia,nodo);
        this.cantColumnas = cantNodos;
        this.cantFilas = cantNodos;
        this.cantInsertados = 0;
    }
    public Grafo getInstance(int cantNodos){
        if(instance == null){
            instance = new Grafo(cantNodos);
        }

        return instance;


    }
    public Grafo(){
        
    }
    public void adherir(Object valorNodo){
        Grafo graf = XMLManager.CrearObjetoGrafo();
        System.out.print(graf.cantInsertados);
        System.out.print(graf.cantFilas);
        graf.adherirNodo(valorNodo);
        XMLManager.crearXMLGrafo(graf);
    }
    public void adherirConecicion(int valor1,int valor2,int pesoConeccion){
        System.out.print(valor1);
        System.out.print(valor2);
        System.out.print(pesoConeccion);
        Grafo graf = XMLManager.CrearObjetoGrafo();
        graf.adherirConexionDirigda(valor1,valor2,pesoConeccion);
        graf.representarMatriz(graf);
        XMLManager.crearXMLGrafo(graf);
    }

    public void adherirNodo(Object valorNodo){
        NodoGrafo nodoInsertar;
        if (valorNodo.getClass() == Tienda.class){
            nodoInsertar = new NodoGrafo((Tienda)valorNodo);
            if(cantInsertados == cantFilas){
                System.out.println("La cantidad maxima de nodos para este grafo a sido alcanzada");
            }
            else{
                arrayReferencia[cantInsertados] = nodoInsertar;
                matriz[cantInsertados][cantInsertados] = 0;
                cantInsertados+=1;
            }
        }
        if (valorNodo.getClass() == CentroDistribucion.class){
            nodoInsertar = new NodoGrafo((CentroDistribucion)valorNodo);
            if(cantInsertados == cantFilas){
                System.out.println("La cantidad maxima de nodos para este grafo a sido alcanzada");
            }
            else{
                arrayReferencia[cantInsertados] = nodoInsertar;
                matriz[cantInsertados][cantInsertados] = 0;
                cantInsertados+=1;
            }
        }
        if (valorNodo.getClass() == Gasolinera.class){
            nodoInsertar = new NodoGrafo((Gasolinera)valorNodo);
            if(cantInsertados == cantFilas){
                System.out.println("La cantidad maxima de nodos para este grafo a sido alcanzada");
            }
            else{
                arrayReferencia[cantInsertados] = nodoInsertar;
                matriz[cantInsertados][cantInsertados] = 0;
                cantInsertados+=1;
            }
        }
    }
    public void adherirConexionDirigda(int valor1,int valor2,int pesoConeccion){//establece un eje con direccion va del nodoConectar1 al nodoConectar2
        int x = 0;
        int posicionNodo1 =0;
        while(x!=arrayReferencia.length){
            if(arrayReferencia[x]!=null){
                if(arrayReferencia[x].Get().getClass() == Tienda.class){
                    if(arrayReferencia[x].getValor().getIdGrafo()==valor1){
                        posicionNodo1 = x;
                    }
                }
                if(arrayReferencia[x].Get().getClass() == Gasolinera.class){
                    if(arrayReferencia[x].getGasolinera().getIdGrafo()==valor1){
                        posicionNodo1 = x;
                    }
                }
                if(arrayReferencia[x].Get().getClass() == CentroDistribucion.class){
                    if(arrayReferencia[x].getCentro().getIdGrafo()==valor1){
                        posicionNodo1 = x;
                    }
                }
                x++;
            }
            else{
                x++;
            }
        }


        int y = 0;
        int posicionNodo2 = 0;
        while(y!=arrayReferencia.length){
            if(arrayReferencia[y]!=null){
                if(arrayReferencia[y].Get().getClass() == Tienda.class){
                    if(arrayReferencia[y].getValor().getIdGrafo()==valor2){
                        posicionNodo2 = y;
                    }
                }
                if(arrayReferencia[y].Get().getClass() == Gasolinera.class){
                    if(arrayReferencia[y].getGasolinera().getIdGrafo()==valor2){
                        posicionNodo2 = y;
                    }
                }
                if(arrayReferencia[y].Get().getClass() == CentroDistribucion.class){
                    if(arrayReferencia[y].getCentro().getIdGrafo()==valor2){
                        posicionNodo2 = y;
                    }
                }
                y++;
            }
            else{
                y++;
            }
        }

        matriz[posicionNodo1][posicionNodo2] = pesoConeccion;
    }

    public void adherirConexionNoDirigida(int valor1,int valor2,int pesoConeccion){
        int x = 0;
        while(arrayReferencia[x].getValor().getIdGrafo()!= valor1){
            x+=1;
        }
        int posicionNodo1 = x;
        int y = 0;
        while(arrayReferencia[y].getValor().getIdGrafo()!= valor2){
            y+=1;
        }
        int posicionNodo2 = y;
        matriz[posicionNodo1][posicionNodo2] = pesoConeccion;
        matriz[posicionNodo2][posicionNodo1] = pesoConeccion;
    }
    public int[] Djikstra(int ValorNodoInicial){
        int caminosCortos[] = new int[cantFilas];
        Boolean[] revisado = new Boolean[cantFilas];
        for(int x = 0;x<cantFilas;x++){
            caminosCortos[x] = Integer.MAX_VALUE;//infinito
            revisado[x] = false;
        }
        int x2=0;
        while(arrayReferencia[x2].getValor().getIdGrafo()!=ValorNodoInicial){
            x2+=1;
        }
        caminosCortos[x2] = 0;//o ya que es la posicion al nodo en el que ya estoy
        for(int contador = 0;contador<cantFilas-1;contador++){
            int u = esDistanciaMinima(caminosCortos,revisado);//revisa si el nuevo valor es minimo o no si lo es lo retorna
            revisado[u] = true;//lo pone como true ya que ya fue revisado
            for(int contador2 =0;contador2<cantFilas;contador2++){//recorre el array
                if (!revisado[contador2] && matriz[u][contador2]!=0 && caminosCortos[u] != Integer.MAX_VALUE && caminosCortos[u]+matriz[u][contador2] <caminosCortos[contador2]){//revisa si tiene una coneccion en la matriz y si el nuevo camino si es menor
                    caminosCortos[contador2] = caminosCortos[u] + matriz[u][contador2];

                }
            }
        }
        return caminosCortos;
    }
    public int esDistanciaMinima(int caminosCortos[], Boolean revisado[]) {
        int mininmo = Integer.MAX_VALUE;
        int min_index=-1;
        for (int contador = 0; contador < cantFilas; contador++){
            if (revisado[contador] == false && caminosCortos[contador] < mininmo) {//revisa si el nodo ya se uso y si no es igual a infinito en la primera revision luego lo compara con los valores del arreglo
                mininmo = caminosCortos[contador];
                min_index = contador;
            }
        }
        return min_index;
    }

    public Tienda[] Djikstra2(int ValorNodoInicial,int valorNodoFinal){
        Tienda caminoTiendas[][] = new Tienda[cantFilas][cantFilas];
        int llenar = 0;
        int encontrarValor = 0;
        while(llenar!=cantFilas){
            Arrays.fill(caminoTiendas[llenar],null);
            llenar+=1;
        }
        int caminosCortos[] = new int[cantFilas];
        Boolean[] revisado = new Boolean[cantFilas];
        for(int x = 0;x<cantFilas;x++){
            caminosCortos[x] = Integer.MAX_VALUE;//infinito
            revisado[x] = false;
        }
        int x2=0;
        while(encontrarValor!=cantInsertados){
            if(arrayReferencia[encontrarValor].Get().getClass() == Tienda.class){
                if(arrayReferencia[encontrarValor].getValor().getIdGrafo()==ValorNodoInicial){
                    x2 = encontrarValor;
                }
            }
            encontrarValor+=1;
        }
        caminosCortos[x2] = 0;//o ya que es la posicion al nodo en el que ya estoy
        //caminoTiendas[x2][0] = arrayReferencia[x2].getValor();
        for(int contador = 0;contador<cantInsertados;contador++){
            int u = esDistanciaMinima(caminosCortos,revisado);//revisa si el nuevo valor es minimo o no si lo es lo retorna
            revisado[u] = true;//lo pone como true ya que ya fue revisado
            if(arrayReferencia[u].Get().getClass()==Tienda.class){
                for(int contador2 =0;contador2<cantFilas;contador2++){//recorre el array
                    if (!revisado[contador2] && matriz[u][contador2]!=0 && caminosCortos[u] != Integer.MAX_VALUE && caminosCortos[u]+matriz[u][contador2] <caminosCortos[contador2] && caminosCortos[u]+matriz[u][contador2]>0 ){//revisa si tiene una coneccion en la matriz y si el nuevo camino si es menor
                        caminosCortos[contador2] = caminosCortos[u] + matriz[u][contador2];
                        Arrays.fill(caminoTiendas[contador2],null);
                        int n = 0;
                        boolean cond = false;
                        while(cond != true){
                            if(caminoTiendas[u][n]==null){
                                caminoTiendas[contador2][n] = arrayReferencia[u].getValor();
                                cond = true;
                            }
                            else{
                                caminoTiendas[contador2][n] = caminoTiendas[u][n];
                            }
                            n++;
                        }
                    }
                }

            }
            else{
                int con2 =0;
                while(con2 !=cantFilas){
                    if(matriz[u][con2]!=0){
                        if(caminosCortos[con2]==Integer.MAX_VALUE){
                            caminosCortos[con2]=Integer.MAX_VALUE-1;
                        }
                    }
                    con2++;
                }
            }
        }
        x2=0;
        encontrarValor=0;
        while(encontrarValor!=cantInsertados){
            if(arrayReferencia[encontrarValor].Get().getClass() == CentroDistribucion.class){
                if(arrayReferencia[encontrarValor].getCentro().getIdGrafo()==valorNodoFinal){
                    x2 = encontrarValor;
                }
            }
            encontrarValor+=1;
        }
        return caminoTiendas[x2];
}
    public int[][] Floyd(int[][] matrizDeConecciones){
        for(int contador = 0;contador<cantFilas;contador++){
            for(int contador2=0;contador2<cantFilas;contador2++){
                if(matrizDeConecciones[contador][contador2]==0){
                    matrizDeConecciones[contador][contador2] = INF;
                }
            }
        }
        int caminosCortos[][] = new int[cantFilas][cantFilas];
        int x;//contador
        int y;//contador
        int z;//contador
        for(x=0;x<cantFilas;x++){
            for(y=0;y<cantFilas;y++){
                caminosCortos[x][y] = matrizDeConecciones[x][y];
            }
        }
        for(z=0;z<cantFilas;z++){//recorrer
            for(x=0;x<cantFilas;x++){//recorrer filas
                for(y=0;y<cantFilas;y++){//recorrer columnas
                    if(caminosCortos[x][z]+caminosCortos[z][y]<caminosCortos[x][y]){//comparacion del camino que se tiene actual
                        if(caminosCortos[x][z]+caminosCortos[z][y]!=0){
                            caminosCortos[x][y] = caminosCortos[x][z] + caminosCortos[z][y];
                        }
                    }
                }
            }
        }
        return caminosCortos;
    }
    public int[][] Warshall(int[][]matrizDeConecciones){
        for(int contador = 0;contador<cantFilas;contador++){
            for(int contador2=0;contador2<cantFilas;contador2++){
                if(matrizDeConecciones[contador][contador2]==0){
                    if(contador == contador2){

                    }
                    else{
                        matrizDeConecciones[contador][contador2] = INF;
                    }
                }
            }
        }
        int caminosCortos[][] = new int[cantFilas][cantFilas];
        int x;//contador
        int y;//contador
        int z;//contador
        for(x=0;x<cantFilas;x++){
            for(y=0;y<cantFilas;y++){
                caminosCortos[x][y] = matrizDeConecciones[x][y];
            }
        }
        for(z=0;z<cantFilas;z++){//recorrer
            for(x=0;x<cantFilas;x++){//recorrer filas
                for(y=0;y<cantFilas;y++){//recorrer columnas
                    if(caminosCortos[x][z]+caminosCortos[z][y]<=caminosCortos[x][y]&&caminosCortos[x][z]!=INF&&caminosCortos[z][y]!=INF){//comparacion del camino que se tiene actual
                        if(caminosCortos[x][z]+caminosCortos[z][y]!=0){
                            caminosCortos[x][y] = 1;
                        }
                    }
                }
            }
        }
        return caminosCortos;
    }
    public int[] Prim(int[][]matrizDeConecciones){
        int[] MST = new int[cantFilas];//lista que representara el minimal spanning tree
        int[] minimosValores = new int[cantFilas];
        Boolean[] revisado = new Boolean[cantFilas];
        for(int contador =0;contador<cantFilas;contador++){
            minimosValores[contador] = INF;
            revisado[contador] = false;
        }
        minimosValores[0]=0;//inicial ruta a el mismo es 0
        MST[0] = 0;
        for(int contador2=0;contador2<cantFilas-1;contador2++){//cantidad de vertices sera cantidad de nodos -1
            int minimo = esDistanciaMinima(minimosValores,revisado);
            revisado[minimo] = true;//ya se visito este nodo
            for(int contador3=0; contador3<cantFilas;contador3++){
                if(matrizDeConecciones[minimo][contador3]!=0&&revisado[contador3]==false&&matriz[minimo][contador3]< minimosValores[contador3]){
                    MST[contador3] = matrizDeConecciones[minimo][contador3];
                    minimosValores[contador3] = matrizDeConecciones[minimo][contador3];
                }
            }
        }
        return MST;

    }
    public void representarMatriz(Grafo graf){
        System.out.print("ID ");
        int x = 0;
        while(x!= graf.cantInsertados){
            if(arrayReferencia[x].Get().getClass()== Tienda.class){
                if(x==cantInsertados-1){
                    System.out.println(graf.arrayReferencia[x].getValor().getIdGrafo()+" " );
                }
                else{
                    System.out.print(graf.arrayReferencia[x].getValor().getIdGrafo()+" " );
                }
            }
            if(arrayReferencia[x].Get().getClass()== CentroDistribucion.class){
                if(x==cantInsertados-1){
                    System.out.println(graf.arrayReferencia[x].getCentro().getIdGrafo()+" " );
                }
                else{
                    System.out.print(graf.arrayReferencia[x].getCentro().getIdGrafo()+" " );

                }
            }
            if(arrayReferencia[x].Get().getClass()== Gasolinera.class){
                if(x==cantInsertados-1){
                    System.out.println(graf.arrayReferencia[x].getGasolinera().getIdGrafo()+" " );

                }
                else{
                    System.out.print(graf.arrayReferencia[x].getGasolinera().getIdGrafo()+" " );
                }
            }
            x++;

        }
        for(int cont1=0;cont1<cantInsertados;cont1++){
            if(arrayReferencia[cont1].Get().getClass()== Tienda.class){

                System.out.print(graf.arrayReferencia[cont1].getValor().getIdGrafo()+"  " );

            }
            if(arrayReferencia[cont1].Get().getClass()== CentroDistribucion.class){

                System.out.print(graf.arrayReferencia[cont1].getCentro().getIdGrafo()+"  " );

            }
            if(arrayReferencia[cont1].Get().getClass()== Gasolinera.class){

                System.out.print(graf.arrayReferencia[cont1].getGasolinera().getIdGrafo()+"  " );

            }
            for(int cont2=0;cont2<cantInsertados;cont2++){
                if (cont2==cantInsertados-1){
                    System.out.println(graf.matriz[cont1][cont2]+" ");
                }
                else{
                    System.out.print(graf.matriz[cont1][cont2]+" ");

                }

            }
        }
    }

}
