/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eTec.clases.java;

import eTec.clases.entity.Administrador;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jonathan
 * 
 */
@Named("lista")
@RequestScoped
@XmlRootElement
public class LinkList{
    private static LinkList instance;
    private ObjetoaXML XMLManager = new ObjetoaXML();
    @XmlElement
    private Link firstLink;//raiz
    @XmlElement
    private int tamaño;//tamaño
    
    protected LinkList(){//consturctor
        firstLink = null;

    }
    public void getInstance2(Administrador cantidad){
        LinkList lista = XMLManager.CrearObjeto();
        lista.insertFirstLink(cantidad);
        XMLManager.crearXML(lista);
    }
    public static LinkList getInstance(){
        if(LinkList.instance == null){
            LinkList.instance = new LinkList();
        }
        return instance;
    }
    public boolean isEmpty(){
        return(firstLink == null);
    }//funcion para revisar si esta vacia

    public void insertFirstLink(Administrador cantidad){
        Link newLink = new Link(cantidad);
        insertFirstLink(newLink);
    }
   private void insertFirstLink(Link link){//inserta un nodo en la primer posicion
       link.setNext(firstLink);
       firstLink = link;
       tamaño++;
       System.out.print(link.getT().getNombre());
    }
   public Link getFirstLink(){
       return this.firstLink;
   }
    public void insertLink(Administrador cantidad,int contador){
        if(contador>tamaño){
            System.out.println("Es imposible insertar en esta posicion");
        }
        else{
            if(contador == 0){
                insertFirstLink(cantidad);
               
            }
            else{
                Link LinkInsertar = new Link(cantidad);
                insertLink(LinkInsertar,contador);
            }
        }

    }
    private void insertLink(Link LinkInsertar, int contador){//contador define la posicion notar que las posiciones empienza de 0
        Link LinkActual = firstLink;
        Link LinkPrevio = LinkActual;
        int x = 0;
        while(x!=contador){
            LinkPrevio = LinkActual;
            LinkActual = LinkActual.getNext();
            x = x+1;
        }
        LinkPrevio.setNext(LinkInsertar);
        LinkInsertar.setNext(LinkActual);
        tamaño++;
    }
    public Link removeFirst(){//elimina un nodo
        Link linkReference = firstLink;

        if(!isEmpty()) {
            firstLink = firstLink.getNext();
            tamaño++;
        }else{
            System.out.println("Empty");
        }

        return linkReference;
    }
    public void removeEspecifico(int contador){//elimina un nodo en la posicion especifica
        if(contador == 0){
            removeFirst();
        }
        else{
            Link LinkActual = firstLink;
            Link LinkPrevio = LinkActual;
            int x = 0;
            while(x!=contador){
                LinkPrevio = LinkActual;
                LinkActual = LinkActual.getNext();
                x = x+1;
            }
            LinkPrevio.setNext(LinkActual.getNext());
            tamaño--;
        }

    }
    public Link getNodoEspecifico(int posicion){//conseguir un nodo en la posicion especifica
        Link linkActual = firstLink;
        int x = 0;
        while(x!=posicion){
            linkActual = linkActual.getNext();
            x+=1;
        }
        return linkActual;
    }
    public void display(){
        Link theLink =  firstLink;
        while(theLink != null){
            theLink.display();
            theLink = theLink.getNext();
        }
    }

    public int getTamaño() {
        return tamaño;
    }
}
