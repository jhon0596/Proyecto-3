/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eTec.clases.java;

import eTec.clases.entity.Administrador;
import eTec.clases.entity.Tienda;
import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

/**
 *
 * @author Jonathan
 */
public class ObjetoaXML {
    public ObjetoaXML(){
        
    }
    
    public LinkList CrearObjeto(){
        try {

		File file = new File("C:\\Users\\Jonathan\\Documents\\NetBeansProjects\\Lista.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(LinkList.class);

		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		LinkList arbol = (LinkList) jaxbUnmarshaller.unmarshal(file);
		return arbol;

	  } catch (JAXBException e) {
		e.printStackTrace();
                return null;
	  }
    }
    public void crearXML(LinkList abb){
        try {

		File file = new File("C:\\Users\\Jonathan\\Documents\\NetBeansProjects\\Lista.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(LinkList.class);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

		// output pretty printed
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

		jaxbMarshaller.marshal(abb, file);
		jaxbMarshaller.marshal(abb, System.out);

	      } catch (JAXBException e) {
		e.printStackTrace();
	      }
    }
    
    
    
    public Grafo CrearObjetoGrafo(){
        try {

		File file = new File("C:\\Users\\Jonathan\\Documents\\NetBeansProjects\\Grafo.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(Grafo.class);

		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		Grafo arbol = (Grafo) jaxbUnmarshaller.unmarshal(file);
		return arbol;

	  } catch (JAXBException e) {
		e.printStackTrace();
                return null;
	  }
    }
    public void crearXMLGrafo(Grafo abb){
        try {

		File file = new File("C:\\Users\\Jonathan\\Documents\\NetBeansProjects\\Grafo.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(Grafo.class);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

		// output pretty printed
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

		jaxbMarshaller.marshal(abb, file);
		jaxbMarshaller.marshal(abb, System.out);

	      } catch (JAXBException e) {
		e.printStackTrace();
	      }
    }
    public static void main(String[] args) {
       Grafo graf = new Grafo(30); 
       ObjetoaXML XMLManager = new ObjetoaXML();
       XMLManager.crearXMLGrafo(graf);
     
    }
    
}
