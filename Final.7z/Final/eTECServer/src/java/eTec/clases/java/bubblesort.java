/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eTec.clases.java;

/**
 *
 * @author Jonathan
 */
public class bubblesort {
	public static LinkList bubbleSort(LinkList lista){
		int x = lista.getTamaño();
		return bubbleSort2(lista,x-1);
	}
        public static LinkList bubbleSortCodigo(LinkList lista){
		int x = lista.getTamaño();
		return bubbleSort2Codigo(lista,x-1);
	}
	private static LinkList bubbleSort2(LinkList lista, int nElements){
    	int in;//limite de comparacion izquierdo
    	int out;//limite de comparacion derecho
    	for (out = nElements; out>=1;out--){//comparacion de in con out
    		for (in = 0; in<out;in++){
    			//if (((String) ((Ingrediente) lista.obtenerPorPosicion(in).getDataT()).getNombre()).compareToIgnoreCase((String) ((Ingrediente) lista.obtenerPorPosicion(out).getDataT()).getNombre())>0){
				if(lista.getNodoEspecifico(in).getT().getNombre().compareTo(lista.getNodoEspecifico(out).getT().getNombre())>0){// si in es mayor
    				swap(in,out,lista);//intercambio en la lista
    			}
    		}}
    		return lista;

    	}
        private static LinkList bubbleSort2Codigo(LinkList lista, int nElements){
    	int in;//limite de comparacion izquierdo
    	int out;//limite de comparacion derecho
    	for (out = nElements; out>=1;out--){//comparacion de in con out
    		for (in = 0; in<out;in++){
    			//if (((String) ((Ingrediente) lista.obtenerPorPosicion(in).getDataT()).getNombre()).compareToIgnoreCase((String) ((Ingrediente) lista.obtenerPorPosicion(out).getDataT()).getNombre())>0){
				if(lista.getNodoEspecifico(in).getT().getIdAdministrador().compareTo(lista.getNodoEspecifico(out).getT().getIdAdministrador())>0){// si in es mayor
    				swap(in,out,lista);//intercambio en la lista
    			}
    		}}
    		return lista;

    	}
	public static void swap(int posicion1, int posicion2, LinkList lista) {
        Link link1 = lista.getNodoEspecifico(posicion1);
        Link link2 = lista.getNodoEspecifico(posicion2);
        Link temp = new Link(link1.getT());
        link1.setT(link2.getT());
        link2.setT(temp.getT());
    }

}
