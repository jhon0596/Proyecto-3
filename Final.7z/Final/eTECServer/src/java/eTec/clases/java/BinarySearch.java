/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eTec.clases.java;

import eTec.clases.entity.Administrador;

/**
 *
 * @author Jonathan
 */
public class BinarySearch {
    private ObjetoaXML XMLManager = new ObjetoaXML();
    public static Boolean binarySearchNombre(LinkList lista,String input){//input es el valor que se desea buscar
        return binarySearchNombre(lista,input,0,lista.getTamaño()-1);
    }
    public static Boolean binarySearchNombre(LinkList lista, String input, int minindex, int maxindex){
        String comparar1 = input;
        while(maxindex>=minindex){//mientras aun se tiene una lista
            int middle = (maxindex + minindex)/2;//la mitad de la lista
            String comparar2= lista.getNodoEspecifico(middle).getT().getNombre();
            if(comparar2.compareTo(comparar1)<0){//se compara si es mayor menor o igual
                minindex = middle+1;
            }else if(comparar2.compareTo(comparar1)>0){
                maxindex = middle-1;
            }else{
                return true;
            }
        }
        return false;
    }
    public static Boolean binarySearchCodigo(LinkList lista,String input){//input es el valor que se desea buscar
        return binarySearchCodigo(lista,input,0,lista.getTamaño()-1);
    }
    public static Boolean binarySearchCodigo(LinkList lista, String input, int minindex, int maxindex){
        String comparar1 = input;
        while(maxindex>=minindex){//mientras aun se tiene una lista
            int middle = (maxindex + minindex)/2;//la mitad de la lista
            String comparar2= lista.getNodoEspecifico(middle).getT().getIdAdministrador();
            if(comparar2.compareTo(comparar1)<0){//se compara si es mayor menor o igual
                minindex = middle+1;
            }else if(comparar2.compareTo(comparar1)>0){
                maxindex = middle-1;
            }else{
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        LinkList lista = new  LinkList();
        Administrador a = new Administrador();
        a.setNombre("Gabriel");
        a.setIdAdministrador("13");
        lista.insertFirstLink(a);
        System.out.print(binarySearchNombre(lista,"Gabriel"));
        System.out.print(binarySearchCodigo(lista,"13"));
        
    } 

   
}
