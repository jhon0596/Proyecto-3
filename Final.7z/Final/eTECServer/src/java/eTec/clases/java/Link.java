package eTec.clases.java;

import eTec.clases.entity.Administrador;
import eTec.clases.entity.Tienda;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by Gabriel on 9/11/2016.
 */
@XmlRootElement
public class Link<T extends Comparable<T>> {//Nodo de la lista enlazada


    private Administrador T;//variable generica

    private Link next;//referencia a sigueinte nodo

    public Administrador getT() {
        return T;
    }

    public void setT(Administrador t) {
        T = t;
    }

    public void setNext(Link next) {
        this.next = next;
    }

    public Link getNext() {
        return next;
    }

    public Link(Administrador cantidad){
        this.T = cantidad;

    }
    public void display(){
        if(this.next==null){
            System.out.print(T);
        }
        else{
            System.out.print(T+"--> ");
        }
    }
    public void displayCola(){
        System.out.println(T);
    }
    public Link(){
        
    }

    public static void main(String[] args) {
    }
}




