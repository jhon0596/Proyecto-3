/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eTec.clases.entity;



import eTec.clases.java.NodoTienda;
import java.io.Serializable;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jonathan
 */
@Entity
@Named("tienda")
@RequestScoped
@XmlRootElement
public class Tienda implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private int idGrafo;
    private String nombre;
    private int ubicacion;
    private String correo;
    private Producto[] producto = new Producto[10];
    private int posicionLista = 0;
    
    public Producto getProducto() {
        return producto[0];
    }
    public Producto[] prodcuto(int x){
        return producto;
    }

    public void setProducto(Producto t) {
        this.producto[posicionLista] = t;
        posicionLista+=1;
    }
    public void ponerProducto(Producto t){
        this.producto[posicionLista] = t;
        posicionLista+=1;
    }
    
    /**
     * Get the value of idGrafo
     *
     * @return the value of idGrafo
     */
    public int getIdGrafo() {
        return idGrafo;
    }

    /**
     * Set the value of idGrafo
     *
     * @param idGrafo new value of idGrafo
     */
    public void setIdGrafo(int idGrafo) {
        this.idGrafo = idGrafo;
    }

    


    /**
     * Get the value of correo
     *
     * @return the value of correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Set the value of correo
     *
     * @param correo new value of correo
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }


    /**
     * Get the value of ubicacion
     *
     * @return the value of ubicacion
     */
    public int getUbicacion() {
        return ubicacion;
    }

    /**
     * Set the value of ubicacion
     *
     * @param ubicacion new value of ubicacion
     */
    public void setUbicacion(int ubicacion) {
        this.ubicacion = ubicacion;
    }


    /**
     * Get the value of nombre
     *
     * @return the value of nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Set the value of nombre
     *
     * @param nombre new value of nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tienda)) {
            return false;
        }
        Tienda other = (Tienda) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "eTec.clases.entity.Tienda[ id=" + id + " ]";
    }
    
    public Tienda(){
       String nombre = this.getNombre();
       String correo = this.getCorreo();
       int ubicacion = this.getUbicacion();
       int idGrafo = this.getIdGrafo();
       
    }
        
       

}
