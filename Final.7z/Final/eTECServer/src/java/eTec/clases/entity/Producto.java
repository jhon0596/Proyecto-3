/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eTec.clases.entity;

import eTec.clases.java.NodoGrafo;
import java.io.Serializable;
import java.util.Arrays;
import javax.inject.Named;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jonathan
 */
@Entity
@Named("producto")
@XmlRootElement
public class Producto implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String nombre;
    private String precio;
    private Tienda[] tienda = new Tienda[10];
    private int posicionLista = 0;


    public Tienda getTienda() {
        return tienda[0];
    }
    public Tienda[] tienda(int x){
        return tienda;
    }

    public void setTienda(Tienda t) {
        this.tienda[posicionLista] = t;
        posicionLista+=1;
    }
    public void ponerTienda(Tienda t){
        this.tienda[posicionLista] = t;
        posicionLista+=1;
    }

    /**
     * Get the value of precio
     *
     * @return the value of precio
     */
    public String getPrecio() {
        return precio;
    }

    /**
     * Set the value of precio
     *
     * @param precio new value of precio
     */
    public void setPrecio(String precio) {
        this.precio = precio;
    }


    /**
     * Get the value of nombre
     *
     * @return the value of nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Set the value of nombre
     *
     * @param nombre new value of nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Producto)) {
            return false;
        }
        Producto other = (Producto) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "eTec.clases.entity.Producto[ id=" + id + " ]";
    }
    
}
