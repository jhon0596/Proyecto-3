package eTec.clases.java;
import eTec.clases.entity.*;
/**
 * Created by Gabriel on 5/27/2017.
 */
public class NodoGrafo<T extends Comparable<T>> {
    private Tienda valor;
    private CentroDistribucion centro;
    
    public NodoGrafo(Tienda valor){
        this.valor = valor;
    }
    public NodoGrafo(CentroDistribucion valor){
        this.centro = valor;
    }
    public NodoGrafo(Gasolinera valor){
        this.gasolinera = valor;
    }

    public CentroDistribucion getCentro() {
        return centro;
    }

    public void setCentro(CentroDistribucion centro) {
        this.centro = centro;
    }

    public Gasolinera getGasolinera() {
        return gasolinera;
    }

    public void setGasolinera(Gasolinera gasolinera) {
        this.gasolinera = gasolinera;
    }
    private Gasolinera gasolinera;

    public Tienda getValor() {
        return valor;
    }

    public void setValor(Tienda valor) {
        this.valor = valor;
    }
}
