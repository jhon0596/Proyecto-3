package eTec.clases.java;
import eTec.clases.entity.*;
/**
 * Created by Gabriel on 5/27/2017.
 */
public class NodoGrafo<T extends Comparable<T>> {
    private Tienda valor;

    public NodoGrafo(Tienda valor){
        this.valor = valor;
    }

    public Tienda getValor() {
        return valor;
    }

    public void setValor(Tienda valor) {
        this.valor = valor;
    }
}
