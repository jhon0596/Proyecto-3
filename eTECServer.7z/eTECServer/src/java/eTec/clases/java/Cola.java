package eTec.clases.java;

import eTec.clases.entity.Tienda;

/**
 * Created by Gabriel on 5/6/2017.
 */
public class Cola {
    private Link tope;
    private Link fondo;
    public int tamaño;
    public Cola(){
        this.tope = null;
        this.fondo = null;
        tamaño = 0;
    }
    public boolean isEmpty(){
        return tope == null;
    }
    public void encolar(Tienda T){//mete un elemento
        Link link = new Link(T);
        encolar(link);
    }
    private void encolar(Link link){
        if(tope==null){
            this.tope = link;
            this.fondo = link;
            tamaño+=1;
        }
        else{
            fondo.setNext(link);
            this.fondo = link;
            tamaño+=1;
        }
    }
    public void desEncolar(){
        this.tope = tope.getNext();
    }//saca un elemento y avanza la cola
    public Link pop(){//saca un elemento y avanza la cola
        if(tope==null){
            System.out.println("cola esta vacia");
            return  null;
        }
        else{
            Link LinkImprimir = tope;
            desEncolar();
            tamaño+=1;
            return LinkImprimir;
        }
    }
    public void peek(){
         tope.displayCola();
    }
    public void display(){
        Link Link = tope;
        while (Link != null){
            Link.displayCola();
            Link = Link.getNext();
        }
    }

    public Link getTope() {
        return tope;
    }

    public static void main(String[] args) {
        Cola cola = new Cola();
        cola.pop();
        cola.pop();
        cola.pop();
        cola.pop();
        cola.pop();
    }
}
