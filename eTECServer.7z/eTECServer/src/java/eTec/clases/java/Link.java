package eTec.clases.java;

import eTec.clases.entity.Tienda;

/**
 * Created by Gabriel on 9/11/2016.
 */
public class Link<T extends Comparable<T>> {//Nodo de la lista enlazada


    private Tienda T;//variable generica

    private Link next;//referencia a sigueinte nodo

    public Link() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Tienda getT() {
        return T;
    }

    public void setT(Tienda t) {
        T = t;
    }

    public void setNext(Link next) {
        this.next = next;
    }

    public Link getNext() {
        return next;
    }

    public Link(Tienda cantidad){
        this.T = cantidad;

    }
    public void display(){
        if(this.next==null){
            System.out.print(T);
        }
        else{
            System.out.print(T+"--> ");
        }
    }
    public void displayCola(){
        System.out.println(T);
    }

    public static void main(String[] args) {
    }
}




